﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashRegister
{
    class Program
    {
        static void Main(string[] args)
        {
            // declare a new CashRegister object with a sales tax value
            CashRegister myRegister = new CashRegister(0.06);

            // add several dollar amounts
            myRegister.add(20.00);
            myRegister.add(15.50);
            myRegister.add(3.75);

            // display the current cash balance and tax info
            Console.WriteLine("The register has: " + myRegister.report().ToString("C"));
            double taxCollected = myRegister.getSalesTax() * myRegister.report();
            Console.WriteLine("Sales tax rate: " + myRegister.getSalesTax().ToString("P"));
            Console.WriteLine("Sales tax collected: " + taxCollected.ToString("C"));
            Console.ReadLine();
        }
    }

    // CashRegister object definition
    class CashRegister
    {
        // declare a property (class variable)
        public double cash = 0.0;
        private double salesTax = 0.00;

        // define your constructor method here!
        public CashRegister(double aTax)
        {
            setSalesTax(aTax);   // verify and set sales tax
        }

        // define an add() method that takes one double "amount" parameter
        public void add(double amount)
        {
            Console.WriteLine("Adding $" + amount);
            cash += amount;
        }
        // define a report() method that returns one double value
        public double report()
        {
            return cash;
        }

        // the public getSalesTax() getter method
        public double getSalesTax()
        {
            return salesTax;
        }

        // the public setSalesTax() setter method
        public void setSalesTax(double newTax)
        {
            if (newTax >= 0) // safety check!
            {
                salesTax = newTax;
            }
        }
    }
}
